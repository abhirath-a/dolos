# Synthetic video statement pack

All records are project-generated teaching data. DEMO is fictional; these are not real financial records.

Upload all four PDFs together to exercise document processing, or upload all four CSVs for a plain canonical-data comparison. Do not upload both formats into the same investigation: that would represent each transfer twice. Each PDF includes an exact `dolos-transactions.csv` attachment, identified as a machine-readable export on every page. The parser can ingest this export without an LLM call; ordinary PDFs still use configured extraction.

The pack contains the final 1,200 rows (100 complete hours) of the reproducible demo source, split without overlap into two routing-motif exports and two ordinary-payment exports. Upload all four to retain historical context. The routing/ordinary names describe generator motifs, not verified predictions or criminal findings. No ground-truth labels or model scores are included in the exported transactions.

Use the frozen demo artifacts via `DOLOS_MODEL_DIR` when testing these files. Some early history predates the model-selection cutoff and supplies context rather than target scores. Do not retrain on these uploads before evaluating them. Actual model outputs must be checked for the chosen subset; this teaching fixture is not a real-world performance benchmark.

The manifest records row counts and checksums. Recreate with:

```sh
nix develop
uv run --with reportlab --extra pdf-llm python tools/generate_mock_statements.py
```
